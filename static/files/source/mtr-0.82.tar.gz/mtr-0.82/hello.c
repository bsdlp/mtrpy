#include <stdio.h>

typedef int socklen_t; 

socklen_t main (int argc, char **argv)
{
  printf ("hello world. \n"); 
  return 2;
}
